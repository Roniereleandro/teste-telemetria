#include <Arduino.h>
#include "src/GpsParserSafe/TinyGPS++.h"

HardwareSerial gpsSerial(1);
TinyGPSPlus gps;
uint32_t lastReport = 0;
uint32_t previousBytes = 0;
uint32_t previousSentences = 0;
bool showNmea = false;

void setup() {
  Serial.begin(115200);
  gpsSerial.begin(9600, SERIAL_8N1, 16, 17);
  Serial.println("\nTeste NEO-6M | UART 9600 | RX GPIO16 | TX GPIO17");
  Serial.println("Envie n para alternar entre resumo e NMEA bruto.");
}

void loop() {
  while (Serial.available()) {
    if (Serial.read() == 'n') {
      showNmea = !showNmea;
      Serial.println(showNmea ? "NMEA bruto ligado" : "NMEA bruto desligado");
    }
  }

  while (gpsSerial.available()) {
    const char byte = gpsSerial.read();
    gps.encode(byte);
    if (showNmea) Serial.write(byte);
  }

  const uint32_t now = millis();
  if (now - lastReport < 2000) return;
  lastReport = now;

  const uint32_t bytes = gps.charsProcessed();
  const uint32_t sentences = gps.passedChecksum();
  const bool freshFix = gps.location.isValid() && gps.location.age() <= 5000;
  Serial.printf("\nBytes no intervalo: %lu | NMEA validas: %lu | Checksums invalidos (total): %lu\n",
                (unsigned long)(bytes - previousBytes),
                (unsigned long)(sentences - previousSentences),
                (unsigned long)gps.failedChecksum());
  if (bytes == previousBytes) Serial.println("Sem dados na UART do GPS");
  else if (sentences == previousSentences) Serial.println("Sem sentenca NMEA valida no intervalo");
  else if (!freshFix) Serial.println("NMEA recebida | aguardando posicao atual");
  previousBytes = bytes;
  previousSentences = sentences;

  if (gps.satellites.isValid() && gps.satellites.age() <= 5000)
    Serial.printf("Satelites usados: %lu\n", (unsigned long)gps.satellites.value());
  if (gps.hdop.isValid() && gps.hdop.age() <= 5000)
    Serial.printf("HDOP: %.2f\n", gps.hdop.hdop());
  if (freshFix)
    Serial.printf("Latitude: %.7f | Longitude: %.7f | Idade: %lu ms\n",
                  gps.location.lat(), gps.location.lng(), (unsigned long)gps.location.age());
}
